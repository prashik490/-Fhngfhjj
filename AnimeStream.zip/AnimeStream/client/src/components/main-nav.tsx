import { Link } from "wouter";
import { Button } from "./ui/button";
import { useAuth } from "@/hooks/use-auth";
import { BookOpen } from "lucide-react";

export function MainNav() {
  const { user, logoutMutation } = useAuth();

  return (
    <nav className="border-b">
      <div className="flex h-16 items-center px-4">
        <Link href="/">
          <Button variant="link" className="text-xl font-bold">
            AnimeStream
          </Button>
        </Link>

        <div className="ml-4">
          <a href="/docs" target="_blank" rel="noopener noreferrer">
            <Button variant="ghost" className="gap-2">
              <BookOpen className="h-4 w-4" />
              Documentation
            </Button>
          </a>
        </div>

        <div className="ml-auto flex items-center space-x-4">
          {user?.isAdmin && (
            <Link href="/admin">
              <Button variant="outline">Admin Dashboard</Button>
            </Link>
          )}
          <Button
            variant="ghost"
            onClick={() => logoutMutation.mutate()}
            disabled={logoutMutation.isPending}
          >
            Logout
          </Button>
        </div>
      </div>
    </nav>
  );
}