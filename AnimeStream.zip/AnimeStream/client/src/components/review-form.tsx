import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertReviewSchema } from "@shared/schema";
import { Button } from "./ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "./ui/form";
import { Textarea } from "./ui/textarea";
import { Star } from "lucide-react";

interface ReviewFormProps {
  onSubmit: (data: { rating: number; comment: string }) => void;
  defaultValues?: {
    rating: number;
    comment: string;
  };
  isSubmitting?: boolean;
}

export function ReviewForm({
  onSubmit,
  defaultValues = { rating: 5, comment: "" },
  isSubmitting = false,
}: ReviewFormProps) {
  const form = useForm({
    resolver: zodResolver(
      insertReviewSchema.pick({ rating: true, comment: true })
    ),
    defaultValues,
  });

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <FormField
          control={form.control}
          name="rating"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Rating</FormLabel>
              <FormControl>
                <div className="flex gap-2">
                  {[1, 2, 3, 4, 5].map((rating) => (
                    <Button
                      key={rating}
                      type="button"
                      variant={field.value >= rating ? "default" : "outline"}
                      size="icon"
                      onClick={() => field.onChange(rating)}
                    >
                      <Star
                        className={field.value >= rating ? "fill-current" : ""}
                      />
                    </Button>
                  ))}
                </div>
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="comment"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Comment (Optional)</FormLabel>
              <FormControl>
                <Textarea
                  placeholder="Share your thoughts about this anime..."
                  {...field}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <Button type="submit" className="w-full" disabled={isSubmitting}>
          Submit Review
        </Button>
      </form>
    </Form>
  );
}
