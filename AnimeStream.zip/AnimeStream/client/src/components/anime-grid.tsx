import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Link } from "wouter";
import type { Anime } from "@shared/schema";

interface AnimeGridProps {
  animes: Anime[];
}

export function AnimeGrid({ animes }: AnimeGridProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
      {animes.map((anime) => (
        <Link key={anime.id} href={`/anime/${anime.id}`}>
          <Card className="cursor-pointer hover:bg-accent transition-colors">
            <CardHeader className="space-y-0 pb-2">
              <CardTitle className="text-lg">{anime.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <img
                src={anime.coverImage}
                alt={anime.title}
                className="w-full aspect-[16/9] object-cover rounded-md"
              />
              <div className="mt-2 text-sm text-muted-foreground">
                {anime.genre} • {anime.releaseYear}
              </div>
            </CardContent>
          </Card>
        </Link>
      ))}
    </div>
  );
}
