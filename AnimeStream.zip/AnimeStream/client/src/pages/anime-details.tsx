import { useQuery, useMutation } from "@tanstack/react-query";
import { useParams } from "wouter";
import { Anime, Review } from "@shared/schema";
import { MainNav } from "@/components/main-nav";
import { ReviewForm } from "@/components/review-form";
import { ReviewsList } from "@/components/reviews-list";
import { useAuth } from "@/hooks/use-auth";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function AnimeDetailsPage() {
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth();
  const { toast } = useToast();

  const { data: anime, isLoading: isLoadingAnime } = useQuery<Anime>({
    queryKey: [`/api/animes/${id}`],
  });

  const { data: reviews, isLoading: isLoadingReviews } = useQuery<Review[]>({
    queryKey: [`/api/animes/${id}/reviews`],
  });

  const { data: myReview, isLoading: isLoadingMyReview } = useQuery<Review>({
    queryKey: [`/api/animes/${id}/my-review`],
  });

  const reviewMutation = useMutation({
    mutationFn: async (data: { rating: number; comment: string }) => {
      const res = await apiRequest("POST", `/api/animes/${id}/reviews`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/animes/${id}/reviews`] });
      queryClient.invalidateQueries({ queryKey: [`/api/animes/${id}/my-review`] });
      toast({
        title: "Review submitted",
        description: "Thank you for your feedback!",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to submit review",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  if (isLoadingAnime || isLoadingReviews || isLoadingMyReview) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-border" />
      </div>
    );
  }

  if (!anime) {
    return <div>Anime not found</div>;
  }

  return (
    <div className="min-h-screen bg-background">
      <MainNav />
      <main className="container mx-auto py-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <img
              src={anime.coverImage}
              alt={anime.title}
              className="w-full rounded-lg shadow-md"
            />
            <h1 className="text-3xl font-bold mt-4">{anime.title}</h1>
            <p className="text-muted-foreground mt-2">{anime.genre} • {anime.releaseYear}</p>
            <p className="mt-4">{anime.description}</p>
          </div>

          <div className="space-y-6">
            <div className="bg-card rounded-lg p-6">
              <h2 className="text-2xl font-semibold mb-4">Reviews</h2>
              {user && (
                <div className="mb-6">
                  <h3 className="text-lg font-medium mb-2">
                    {myReview ? "Edit your review" : "Write a review"}
                  </h3>
                  <ReviewForm
                    onSubmit={(data) => reviewMutation.mutate(data)}
                    defaultValues={
                      myReview
                        ? { rating: myReview.rating, comment: myReview.comment || "" }
                        : undefined
                    }
                    isSubmitting={reviewMutation.isPending}
                  />
                </div>
              )}
              <ReviewsList
                reviews={
                  reviews?.map((review) => ({
                    ...review,
                    username: "User " + review.userId, // We should fetch usernames in a real app
                  })) || []
                }
              />
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
