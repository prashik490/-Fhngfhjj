import { useQuery } from "@tanstack/react-query";
import { AnimeGrid } from "@/components/anime-grid";
import { MainNav } from "@/components/main-nav";
import type { Anime } from "@shared/schema";
import { Loader2 } from "lucide-react";

export default function HomePage() {
  const { data: animes, isLoading } = useQuery<Anime[]>({
    queryKey: ["/api/animes"],
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-border" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <MainNav />
      <main className="container mx-auto py-6">
        <h1 className="text-4xl font-bold mb-6">Latest Anime</h1>
        <AnimeGrid animes={animes || []} />
      </main>
    </div>
  );
}
