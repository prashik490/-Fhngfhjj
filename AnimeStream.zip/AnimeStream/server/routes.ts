import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import path from "path";

export async function registerRoutes(app: Express): Promise<Server> {
  setupAuth(app);

  // Documentation route
  app.get("/docs", (req, res) => {
    res.sendFile(path.resolve(__dirname, "..", "documentation.html"));
  });

  app.get("/api/animes", async (req, res) => {
    const animes = await storage.getAnimes();
    res.json(animes);
  });

  app.get("/api/animes/:id", async (req, res) => {
    const anime = await storage.getAnime(parseInt(req.params.id));
    if (!anime) return res.sendStatus(404);
    res.json(anime);
  });

  app.post("/api/animes", async (req, res) => {
    if (!req.user?.isAdmin) return res.sendStatus(403);
    const anime = await storage.createAnime(req.body);
    res.status(201).json(anime);
  });

  app.get("/api/animes/:id/episodes", async (req, res) => {
    const episodes = await storage.getEpisodes(parseInt(req.params.id));
    res.json(episodes);
  });

  app.get("/api/episodes/:id", async (req, res) => {
    const episode = await storage.getEpisode(parseInt(req.params.id));
    if (!episode) return res.sendStatus(404);
    res.json(episode);
  });

  app.post("/api/episodes", async (req, res) => {
    if (!req.user?.isAdmin) return res.sendStatus(403);
    const episode = await storage.createEpisode(req.body);
    res.status(201).json(episode);
  });

  // Review routes
  app.get("/api/animes/:id/reviews", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const reviews = await storage.getReviews(parseInt(req.params.id));
    res.json(reviews);
  });

  app.get("/api/animes/:id/my-review", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const review = await storage.getUserReview(req.user!.id, parseInt(req.params.id));
    res.json(review || null);
  });

  app.post("/api/animes/:id/reviews", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    const existingReview = await storage.getUserReview(
      req.user!.id,
      parseInt(req.params.id)
    );

    if (existingReview) {
      const updatedReview = await storage.updateReview(existingReview.id, {
        ...req.body,
        userId: req.user!.id,
        animeId: parseInt(req.params.id),
      });
      return res.json(updatedReview);
    }

    const review = await storage.createReview({
      ...req.body,
      userId: req.user!.id,
      animeId: parseInt(req.params.id),
    });
    res.status(201).json(review);
  });

  const httpServer = createServer(app);
  return httpServer;
}